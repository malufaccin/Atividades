palavras = input("Digite uma lista de palavras separadas por espaço: ").split()
comprimentos = list(map(len, palavras))

print("Comprimentos das palavras:", comprimentos)
