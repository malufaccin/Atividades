numeros = list(map(float, input("Digite uma lista de números separados por espaço: ").split()))
ref = float(input("Digite um número de referência: "))

posicao = next((i for i, num in enumerate(numeros) if num > ref), None)

if posicao is not None:
    print("A posição do primeiro elemento maior que o número de referência é:", posicao)
else:
    print("Não há elementos maiores que o número de referência na lista.")
