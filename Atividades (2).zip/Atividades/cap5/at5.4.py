div3or5 = [x for x in range(31) if x % 3 == 0 or x % 5 == 0]
print(div3or5)
