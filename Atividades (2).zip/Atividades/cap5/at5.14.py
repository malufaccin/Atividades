alunos = input("Digite uma lista de nomes de alunos separados por espaço: ").split()
notas = list(map(float, input("Digite uma lista de notas dos alunos separadas por espaço: ").split()))

tuplas = list(zip(alunos, notas))
ordem_decrescente = sorted(tuplas, key=lambda x: x[1], reverse=True)

print("Lista em ordem decrescente de nota:")
for nome, nota in ordem_decrescente:
    print(f"({nome}, {nota})")
