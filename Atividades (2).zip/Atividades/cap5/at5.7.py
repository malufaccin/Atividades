aln_nt = {}
for i in range(3):
    nm = input("Digite o nome do aluno: ")
    nt = float(input(f"Digite a nota de {nm}: "))
    aln_nt[nm] = nt
arr = {nome: round(nt) for nome, nt in aln_nt.items()}
print("notas arredondadas")
for nm, nota in arr.items():
    print(f"{nm}: {nt}")
