nomes = input("Digite uma lista de nomes separados por espaço: ").split()
nomes_cx_alta = list(map(str.upper, nomes))

print("Nomes em caixa alta:", nomes_cx_alta)
