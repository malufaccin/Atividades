numeros = input("Digite uma lista de números separados por espaço: ").split()
pares = list(filter(lambda x: int(x) % 2 == 0, numeros))

print("Números pares:", pares)
