import math
numeros = [1, 2, 3, 4, 5,6,7,8,9,10]
quadrados = {x: math.sqrt(x) for x in numeros}
print(quadrados)