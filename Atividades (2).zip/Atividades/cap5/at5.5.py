aln_nt = {}
for i in range(5):
    nm = input("Digite o nome do aluno: ")
    nt = float(input(f"Digite a nota de {nm}: "))
    aln_nt[nm] = nt
mq7 = {nome: nota for nome, nota in aln_nt.items() if nota >= 7}
print("Alunos aprovados:")
for nome, nota in mq7.items():
    print(f"{nome}: {nota}")
