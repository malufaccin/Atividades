frase = input("Digite uma frase: ")
palavras_com_o = [palavra.replace("a", "o") for palavra in frase.split() if "a" in palavra]

print("Palavras com 'a' substituído por 'o':", palavras_com_o)
