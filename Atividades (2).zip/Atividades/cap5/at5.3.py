num = [1,2,3,4,5,6,7,8,9,10]
quadrados = [x**2 for x in num if x % 2 == 0]
print(quadrados)