lista1 = list(map(float, input("Digite a primeira lista de números separados por espaço: ").split()))
lista2 = list(map(float, input("Digite a segunda lista de números separados por espaço: ").split()))

media_elementos = [(x + y) / 2 for x, y in zip(lista1, lista2)]
print("Média dos elementos correspondentes:", media_elementos)
