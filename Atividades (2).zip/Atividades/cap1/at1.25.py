import math

raio = float(input("Digite o raio da esfera: "))
vol = (4/3) * math.pi * raio**3

print(f"O volume da esfera é: {vol}")