vi = float(input("Digite o valor inicial do investimento: "))
tj = float(input("Digite a taxa de juros (em %): ")) / 100
anos = int(input("Digite o número de anos: "))
valor_final = vi * (1 + tj) ** anos

print(f"O valor final do investimento após {anos} anos é: R${valor_final:.2f}")
