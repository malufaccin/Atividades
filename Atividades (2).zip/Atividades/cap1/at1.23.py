d = float(input("Digite a distância percorrida: "))
t = float(input("Digite o tempo gasto: "))
a = float(input("Digite a aceleração: "))

vf= a * t
vi= vf- (a*t)

print(f"A velocidade inicial do objeto é: {vi} m/s e a final é {vf} m/s")