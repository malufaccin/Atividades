peso= float(input("Digite seu peso em kg: "))
altura= float(input("Digite sua altura em metros: "))
imc= peso/(altura**2)
print(f"Seu imc é {imc}")
