nome= input("Digite o nome do produto:")
pc= float(input("Digite o preço de custo do produto:"))
pv= float(input("Digite o preço de venda do produto:"))
qtd= int(input("Digite a quantidade em estoque do produto:"))

valor_gasto = pc*qtd
valor_vdd = pv*qtd
lucro = valor_vdd-valor_gasto

print(f"O lucro do produto {nome} será de {lucro:.2f} reais")