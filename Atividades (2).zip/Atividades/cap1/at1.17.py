pm = float(input("Digite o preço da mercadoria: "))
desc = float(input("Digite o desconto (em %): ")) / 100
imp = float(input("Digite o imposto (em %): ")) / 100
pf = pm * (1 - desc * (1 + imp))

print(f"O preço final da mercadoria é: {pf:.2f} reais")