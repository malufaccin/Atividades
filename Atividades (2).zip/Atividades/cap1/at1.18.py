m = float(input("Digite a massa do objeto: "))
a = float(input("Digite a aceleração do objeto: "))

fr = m * a
print(f"A força resultante sobre o objeto é: {fr} N ")
