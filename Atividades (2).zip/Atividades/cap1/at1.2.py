n1= 6
n2= 3

soma = n1+n2
subtracao=n1-n2
multiplicacao= n1*n2
divisao=n1/n2

print(f"soma: {soma} subtracao: {subtracao} multiplicacao: {multiplicacao} divisao: {divisao}")
