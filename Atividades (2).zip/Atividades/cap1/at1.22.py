d = float(input("Digite a distância percorrida pelo objeto: "))
t = float(input("Digite o tempo gasto: "))
vm=d/t

print(f"A velocidade média do objeto é: {vm} m/s")