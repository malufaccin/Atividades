n1= int(input("Digite o número 1: "))
n2= int(input("Digite o número 2: "))
n3= int(input("Digite o número 3: "))
soma = n1+n2+n3
print(f"A soma é {soma}")