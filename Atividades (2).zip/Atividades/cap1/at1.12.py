import math
raio = float(input("Digite o raio: "))
area = math.pi * raio**2
comp = 2 * math.pi * raio

print(f"A area do circulo é {area} e o comprimento é {comp}")