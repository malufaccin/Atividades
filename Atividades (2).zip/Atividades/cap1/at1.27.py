nome = input("Digite o nome: ")
sal = float(input("Digite o salário: "))
imp = float(input("Digite o valor do imposto: "))

sl = sal - imp

print(f"O salário líquido de {nome} é de: R${sl:.2f}")
