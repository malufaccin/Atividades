import math

cat1 = float(input("Digite o comprimento do cateto 1: "))
cat2 = float(input("Digite o comprimento do cateto 2: "))

hip = math.sqrt(cat1**2 + cat2**2)

print(f"O comprimento da hipotenusa é: {hip}")