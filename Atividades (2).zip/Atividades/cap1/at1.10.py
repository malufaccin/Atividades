n1=int(input("Digite o numero 1: "))
n2=int(input("Digite o numero 2: "))

pot = n1**n2
print(f"a potencia de {n1} elevado a {n2} é {pot}")