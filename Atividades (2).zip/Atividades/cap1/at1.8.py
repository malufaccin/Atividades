import math

num=int(input("Digite um numero: "))
raiz = math.sqrt(num)
print(f"A raíz é {raiz}")