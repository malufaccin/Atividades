import math
g = 10
dis = float(input("Digite a distância em metros: "))
vi = float(input("Digite a velocidade inicial em m/s: "))
tempo = math.sqrt(2 * dis / g)

print(f"O objeto leva aproximadamente {tempo:.2f} segundos para atingir o solo.")
