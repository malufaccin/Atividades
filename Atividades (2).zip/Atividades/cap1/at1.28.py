fam = ["Maria", "Pedro", "Crisciam", "Christian", "Sasha"]

print(f"Os membros da familia são: {fam}")
