import math
a = float(input("Digite o valor de a: "))
b = float(input("Digite o valor de b: "))
c = float(input("Digite o valor de c: "))

delta = b**2 - 4*a*c
if delta >= 0:
    x1 = (-b + math.sqrt(delta)) / (2*a)
    x2 = (-b - math.sqrt(delta)) / (2*a)
    print(f"As raízes são: x1 = {x1} e x2 = {x2}")
else:
    parte_real = -b / (2*a)
    parte_imaginaria = math.sqrt(abs(delta)) / (2*a)
    raiz1 = complex(parte_real, parte_imaginaria)
    raiz2 = complex(parte_real, -parte_imaginaria)
    print(f"As raízes são complexas: x1 = {raiz1} e x2 = {raiz2}")