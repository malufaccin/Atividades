import math

c1 = {1, 2, 3, 4, 5}
c2 = {4, 5, 6, 7, 8}

uniao = c1.union(c2)
inter = c1.intersection(c2)
dif1 = c1.difference(c2)
dif2 = c2.difference(c1)

print("Conjunto 1:", c1)
print("Conjunto 2:", c2)
print("União dos conjuntos:", uniao)
print("Interseção dos conjuntos:", inter)
print("Diferença de c1 - c2:", dif1)
print("Diferença de c2 - c1:", dif2)