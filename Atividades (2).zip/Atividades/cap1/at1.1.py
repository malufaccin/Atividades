nome = "Malu"
idade = 18
print(f"Meu nome é {nome} e tenho {idade} anos")