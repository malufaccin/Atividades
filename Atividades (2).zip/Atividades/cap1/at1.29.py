familia = {
    "Maria": {"idade": 18, "cor_olhos": "verde/castanho"},
    "Pedro": {"idade": 63, "cor_olhos": "azuis"},
    "Crisciam": {"idade": 49, "cor_olhos": "preto"},
    "Christian": {"idade": 26, "cor_olhos": "pretos"},
    "Sasha": {"idade": 3, "cor_olhos": "castanhos"}
}

print("Dados dos membros da minha família:")
for nome, dados in familia.items():
    print(f"Nome: {nome}, Idade: {dados['idade']}, Cor dos olhos: {dados['cor_olhos']}")