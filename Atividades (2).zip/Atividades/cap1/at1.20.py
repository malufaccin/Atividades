import math
an_rad = float(input("Digite o valor do ângulo em radianos: "))
an_gr = an_rad * (180 / math.pi)

print(f"O ângulo em graus é: {an_gr:.2f}")
