vi = float(input("Digite a velocidade inicial: "))
vf = float(input("Digite a velocidade final: "))
tempo = float(input("Digite o tempo de transição: "))

a = (vf - vi) / tempo

print(f"A aceleração do objeto é: {a} m/s²")