lar = float(input("Digite a largura: "))
comp = float(input("Digite o com´primento: "))
per = (lar*2)+(comp*2)
area = lar*comp

print(f"A area é {area} e o peerimetro é {per}")