num= int(input("Digite o número: "))
dobro = num*2
print(f"O dobro do seu número é {dobro}")