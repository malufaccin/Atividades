import math
num=int(input("Digite o número: "))
seno = math.sin(num)
cosseno = math.cos(num)
tangente = math.tan(num)
print(f"O seno é {seno}, o cosseno é {cosseno}, a tangente é {tangente}")