base = float(input("Digite a base do triangulo: "))
alt = float(input("Digite a altura do triangulo: "))
area= (base*alt)/2

print(f"A area do triangulo é {area}")