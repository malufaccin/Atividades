import math

raio = float(input("Digite o raio do círculo: "))
per = 2 * math.pi * raio

print(f"O perímetro do círculo é: {per}")

