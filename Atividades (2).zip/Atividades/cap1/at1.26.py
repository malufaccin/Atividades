cat1 = float(input("Digite o comprimento do cateto1 "))
cat2 = float(input("Digite o comprimento do cateto2: "))
area = (1/2) * cat1 * cat2

print(f"A área do triângulo retângulo é: {area}")
