import math

num = float(input("Digite um número: "))
log = math.log(num)

print("O logaritmo natural de", num, "é", log)
