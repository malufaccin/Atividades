import math
num = float(input("Digite um número: "))

raiz= math.sqrt(num)

print("A raiz quadrada de", num, "é", raiz)
