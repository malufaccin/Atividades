frase = input("Digite uma frase: ")
artigos = ["o", "a", "os", "as", "um", "uma", "uns", "umas"]

palavras = frase.split()
frase_nova = " ".join(palavra for palavra in palavras if palavra.lower() not in artigos)

print("Frase sem os artigos:", frase_nova)
