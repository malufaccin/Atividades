real1 = float(input("Digite a parte real do primeiro número complexo: "))
im1 = float(input("Digite a parte imaginária do primeiro número complexo: "))
real2 = float(input("Digite a parte real do segundo número complexo: "))
im2 = float(input("Digite a parte imaginária do segundo número complexo: "))

num_comp1 = complex(real1, im1)
num_comp2 = complex(real2, im2)

soma = num_comp1 + num_comp2
produto = num_comp1 * num_comp2

print("A soma dos números complexos é:", soma, "e o produto é:", produto)
