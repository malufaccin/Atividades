frase = input("Digite uma frase: ")

palavras = frase.split()
o = sum(1 for palavra in palavras if palavra.endswith("o"))
a = sum(1 for palavra in palavras if palavra.endswith("a"))

print("Palavras terminando com 'o':", o, "Palavras terminando com 'a':", a)

