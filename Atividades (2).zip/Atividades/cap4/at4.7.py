import re

usuario = input("Digite um nome de usuário: ")
senha = input("Digite uma senha: ")

padrao_nao_alfanumerico = re.compile(r'[^a-zA-Z0-9]')

nome_usuario2 = re.sub(padrao_nao_alfanumerico, '', usuario) 
senha2 = re.sub(padrao_nao_alfanumerico, '', senha)

print("Nome de usuário limpo:", nome_usuario2)
print("Senha limpa:", senha2)


