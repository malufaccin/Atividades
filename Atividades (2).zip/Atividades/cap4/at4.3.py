import math
num=int(input("Digite o angulo : "))
seno = math.sin(num)
cosseno = math.cos(num)
tangente = math.tan(num)
print(f"O seno é {seno}, o cosseno é {cosseno}, a tangente é {tangente}")