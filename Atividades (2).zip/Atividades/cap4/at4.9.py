frase = input("Digite uma frase: ")
palavra_ex = input("Digite uma palavra presente na frase: ")
palavra_au = input("Digite uma palavra ausente na frase: ")

nova_frase = frase.replace(palavra_ex, palavra_au)

print("Frase com substituição:")
print(nova_frase)
