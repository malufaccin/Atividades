frase = input("Digite uma frase: ")

palavras = frase.split()
sem_espacos = " ".join(palavra.strip() for palavra in palavras)

print("Frase com espaços desnecessários removidos:")
print(sem_espacos)
