base = float(input("Digite a base: "))
expoente = float(input("Digite o expoente: "))

potencia = base ** expoente

print("A potência de", base, "elevado a", expoente, "é igual a", potencia)
