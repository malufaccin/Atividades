frase = input("Digite uma frase: ")

palavras = frase.split()

contagem_plv = {}
for palavra in palavras:
    contagem_plv[palavra] = contagem_plv.get(palavra, 0) + 1

print("Número de vezes que cada palavra aparece na frase:")
for palavra, contagem in contagem_plv.items():
    print(f"A palavra '{palavra}' aparece {contagem} vezes.")
