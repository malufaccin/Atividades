frase = input("Digite uma frase: ")

palavras = frase.split()

print("Posição inicial de cada palavra na frase:")
for i, palavra in enumerate(palavras, 1):
    print(f"A palavra '{palavra}' começa na posição {i}")
