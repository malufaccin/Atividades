num = int(input("Digite um número para ver sua tabuada: "))

print("Tabuada do", num, ":")
for i in range(1, 11):
    print(num, "x", i, "=", num * i)
