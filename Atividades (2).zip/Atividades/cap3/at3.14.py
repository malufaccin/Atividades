num = int(input("Digite um número inteiro para verificar se é primo: "))

if num > 1:
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            print(num, "não é primo.")
            break
    else:
        print(num, "é primo.")
else:
    print(num, "não é primo.")
