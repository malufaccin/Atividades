nums = []

for i in range(10):
    num = float(input("Digite o número: "))
    nums.append(num)

maior = max(nums)
menor = min(nums)

print("O maior número é:", maior, "e o menor número é:", menor)
