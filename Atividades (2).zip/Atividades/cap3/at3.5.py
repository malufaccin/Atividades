soma_pares = 0

for numero in range(2, 101, 2):
    soma_pares += numero

print("A soma de todos os números pares de 1 a 100 é:", soma_pares)
