palavra = input("Digite uma palavra para verificar se é um palíndromo: ")

palavra_inv = palavra[::-1]

if palavra == palavra_inv:
    print("A palavra é um palíndromo.")
else:
    print("A palavra não é um palíndromo.")
