soma = 0
contador = 0

numero = float(input("Digite um número (digite um número negativo para parar): "))
while numero >= 0:
    soma += numero
    contador += 1
    numero = float(input("Digite outro número (ou um negativo para parar): "))

if contador > 0:
    media = soma / contador
    print("A média dos números digitados é:", media)
else:
    print("Nenhum número foi digitado.")
