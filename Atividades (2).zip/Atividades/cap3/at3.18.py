n = int(input("Digite o número de termos da sequência de Fibonacci que você deseja: "))

fibonacci = [0, 1]

while len(fibonacci) < n:
    proximo_termo = fibonacci[-1] + fibonacci[-2]
    fibonacci.append(proximo_termo)

print(f"Sequência de Fibonacci até o termo numero {n}:" , fibonacci) 

