num = int(input("Digite um número inteiro positivo: "))

if num < 0:
    print("O fatorial não está definido para números negativos.")
elif num == 0:
    print("O fatorial de 0 é 1.")
else:
    fat = 1
    for i in range(1, num + 1):
        fat *= i
    print("O fatorial de", num, "é", fat)
