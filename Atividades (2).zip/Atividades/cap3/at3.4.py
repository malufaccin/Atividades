soma = sum(range(1, 101))
print("A soma de todos os números de 1 a 100 é de:", soma)