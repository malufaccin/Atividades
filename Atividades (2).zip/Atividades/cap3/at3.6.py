soma_impares = 0

for numero in range(1, 101, 2):
    soma_impares += numero

print("A soma de todos os números ímpares de 1 a 100 é:", soma_impares)
