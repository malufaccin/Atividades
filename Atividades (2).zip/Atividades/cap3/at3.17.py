nums = []

for i in range(10):
    num = float(input("Digite o número: "))
    nums.append(num)

ordenados = sorted(nums)

seg_menor = ordenados[1]
seg_maior = ordenados[-2]

print("O segundo menor número é:", seg_menor," e o segundo maior número é:", seg_maior)
