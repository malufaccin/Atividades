sm_primos = 0

for numero in range(2, 101):
    # Verificando se o número é primo
    eh_primo = True
    for i in range(2, numero):
        if numero % i == 0:
            eh_primo = False
            break
    # Se o número for primo, adicionamos à soma
    if eh_primo:
        sm_primos += numero

# Imprimindo a soma dos números primos
print("A soma de todos os números primos de 1 a 100 é:", sm_primos)
