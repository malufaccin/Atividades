idade = int(input("Digite sua idade: "))
gen = input("Digite seu gênero (m/f): ")

if (gen == "f" and idade >= 60) or (gen.lower() == "m" and idade >= 65):
    print("Você é elegível para aposentadoria.")
else:
    print("Você ainda não é elegível para aposentadoria.")