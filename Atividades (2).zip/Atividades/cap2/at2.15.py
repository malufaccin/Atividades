salario = float(input("Digite o seu salário: "))

if salario > 10000:
    print("Alto salário")
else:
    print("Baixo salário")
