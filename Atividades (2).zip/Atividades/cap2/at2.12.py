idade = int(input("Digite sua idade: "))
nac = input("Você é brasileiro? (sim/não): ")

if idade >= 18 and nac == "sim":
    print("Você pode votar.")
else:
    print("Você não pode votar.")
