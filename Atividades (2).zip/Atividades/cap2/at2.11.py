temp = float(input("Digite a temperatura em graus Celsius: "))

if temp < 36:
    print("A temperatura está abaixo do normal.")
elif temp > 37:
    print("A temperatura está acima donormal.")
else:
    print("A temperatura está dentro do normal.")
