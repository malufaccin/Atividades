entrada = input("Digite uma string: ")

decimal = False
for i in range(len(entrada)):
    caractere = entrada[i]
    if not caractere.isdigit():
        if caractere == '.' and not decimal and i != 0 and i != len(entrada) - 1:
            decimal = True
        else:
            print("A string não representa um número real.")
            break
else:
    print("A string representa um número real.")
