gen = input("Digite o seu gênero (M / F): ")

if gen == 'M':
    print("Gênero masculino")
elif gen== 'F':
    print("Gênero feminino")
else:
    print("Gênero não reconhecido")
