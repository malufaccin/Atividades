entrada = input("Digite uma data no formato mm/dd/aaaa: ")

partes = entrada.split('/')
if len(partes) == 3:
    mes, dia, ano = partes
    if mes.isdigit() and dia.isdigit() and ano.isdigit():
        mes = int(mes)
        dia = int(dia)
        ano = int(ano)
        if 1 <= mes <= 12 and 1 <= dia <= 31:
            if mes in [4, 6, 9, 11] and dia > 30:
                print("A string não representa uma data no formato mm/dd/aaaa.")
            elif mes == 2:
                if (ano % 4 == 0 and ano % 100 != 0) or (ano % 400 == 0):
                    if dia > 29:
                        print("A string não representa uma data no formato mm/dd/aaaa.")
                elif dia > 28:
                    print("A string não representa uma data no formato mm/dd/aaaa.")
            else:
                print("A string representa uma data no formato mm/dd/aaaa.")
        else:
            print("A string não representa uma data no formato mm/dd/aaaa.")
    else:
        print("A string não representa uma data no formato mm/dd/aaaa.")
else:
    print("A string não representa uma data no formato mm/dd/aaaa.")
