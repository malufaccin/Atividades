idade = int(input("Digite sua idade: "))

if idade < 30:
    print("Você é jovem.")
elif 30 <= idade <= 60:
    print("Você é adulto.")
else:
    print("Você é idoso.")