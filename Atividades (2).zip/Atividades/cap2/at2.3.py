letra = input("Digite uma letra minuscula: ")

alfabeto = 'abcdefghijklmnopqrstuvwxyz'

if letra in alfabeto:
    if letra in 'aeiou':
        print("A letra digitada é uma vogal.")
    else:
        print("A letra digitada é uma consoante.")
else:
    print("Não é uma letra")
