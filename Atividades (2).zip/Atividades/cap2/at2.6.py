plv = input("Digite uma string: ")
resultado = plv == plv[::-1]

if resultado:
    print("A string é um palíndromo.")
else:
    print("A string não é um palíndromo.")
